import RPi.GPIO as GPIO
import time

# Set the GPIO mode and pin
GPIO.setmode(GPIO.BOARD)
GPIO.setup(12, GPIO.OUT)

# Set the PWM frequency and start the PWM
pwm = GPIO.PWM(12, 50)  # GPIO 12, 50Hz
pwm.start(0)

# Rotate the servo by 45 degrees
duty_cycle = 7.5  # Center position
pwm.ChangeDutyCycle(duty_cycle + 0.15)  # Rotate 45 degrees
time.sleep(1)  # Wait for 1 second

# Stop the PWM and cleanup
pwm.stop()
GPIO.cleanup()