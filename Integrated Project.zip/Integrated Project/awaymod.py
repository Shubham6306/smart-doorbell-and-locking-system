import cv2
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email.utils import COMMASPACE
from email import encoders
from datetime import datetime

import subprocess
import time
import sys


# Set up the email sender and recipient information
def away_mode():
    sender = 'yadavshubham5341@gmail.com'
    recipient = 'sy539977@gmail.com'
    password = 'hxhudwjwfcjeutsq'
    smtp_server = 'smtp.gmail.com'
    smtp_port = 587



    # Take a photo using your default camera and save it as a JPEG file
    cap = cv2.VideoCapture(0)
    ret, frame = cap.read()
    cv2.imwrite('photo.jpg', frame)
    cap.release()

    # Create the email message
    now = datetime.now()
    time = now.strftime("%H:%M")
    date = now.strftime("%Y-%m-%d")

    msg = MIMEMultipart()
    msg['From'] = sender
    msg['To'] = COMMASPACE.join([recipient])
    msg['Subject'] = 'Home Smart Doorbell : Someone was at the door at '+time
    msg.attach(MIMEText('Date : '+date+' || Time : '+time))


    # Attach the photo to the email
    with open('photo.jpg', 'rb') as f:
        img = MIMEBase('application', 'octet-stream')
        img.set_payload(f.read())
        encoders.encode_base64(img)
        img.add_header('Content-Disposition', 'attachment', filename='photo.jpg')
        msg.attach(img)

    # Send the email
    with smtplib.SMTP(smtp_server, smtp_port) as smtp:
        smtp.starttls()
        smtp.login(sender, password)
        smtp.sendmail(sender, recipient, msg.as_string())
        print("Owner has been notified!")
        


away_mode()
