import cv2
import os
import subprocess


# Create a directory to save the photos in
name="Shubham"
path = r"/Users/shubham/Desktop/Integrated Project/imageSets/"+name
if not os.path.exists(path):
    os.makedirs(path)

# Start the camera and detect faces
cap = cv2.VideoCapture(0)
face_cascade = cv2.CascadeClassifier(r"/Users/shubham/Desktop/Integrated Project/haarcascade_frontalface_default.xml")

noface=0

count=0
flag = 0

while count < 10:
    try:
        ret, img = cap.read()
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)
    except cv2.error:
        print("Error")
        flag=-1
        break
        
    if str(faces) == "()":
        noface+=1
    else:
        for (x, y, w, h) in faces:
            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
            roi_gray = gray[y:y + h, x:x + w]
            roi_color = img[y:y + h, x:x + w]
            filename = f"{path}/{name}{count}.jpg"
            cv2.imwrite(filename, roi_gray)
            print("Captured Image ",count)
        count+=1
        
    if noface >= 10:
        flag=1
        break
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
if flag==0:
    print("face added")
elif flag==1:
    print("face not detected")

