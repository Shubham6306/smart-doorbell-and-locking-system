import numpy as np
import cv2
import os
from PIL import Image

data_dir = r"C:\Users\psank\Desktop\Test\imageSets"
path = [os.path.join(data_dir, file) for file in os.listdir(data_dir)]        
faces = []
labels = []

for image in path:
    image_instance = Image.open(image).convert('L') # convert to grayscale 
    np_instance = np.array(image_instance, 'uint8')
    name = os.path.splitext(os.path.basename(image))[0]
    name = ''.join(filter(str.isalpha, name))
    faces.append(np_instance)
    labels.append(name)

    cv2.imshow("Training", np_instance)
    cv2.waitKey(1) == 13
    
labels = np.array(labels)
labels = np.arange(len(labels))
labels = labels.astype(np.int32)

clf = cv2.face.LBPHFaceRecognizer_create()
clf.train(faces, labels)
clf.write(r"C:\Users\psank\Desktop\Test\trained_data.xml")
cv2.destroyAllWindows()
