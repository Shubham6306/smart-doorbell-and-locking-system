import RPi.GPIO as GPIO
import subprocess
import cv2
import subprocess
import time
import sys

def auto_fr():
    face_cascade = cv2.CascadeClassifier(r"/home/pi/Desktop/Integrated Project/haarcascade_frontalface_default.xml")
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read(r'/home/pi/Desktop/Integrated Project/Trained.xml')

    known_faces = ['Sankalp','Shubham','Pradeep','Viprawar']

    cam_frame = cv2.VideoCapture(0) #starting the video capture ( 0 = default cam , 1 = usb cam)
    
    sam_conf = 10
    count = 1
    arr_conf = []
    arr_var = 0

    while True:

        # Read frame from video capture
        ret,frame = cam_frame.read()

        # Convert frame to grayscale
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Detect face_frame in the frame
        face_frame = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)

        cvalue=0
        
        # Loop over detected face_frame
        for (x, y, w, h) in face_frame:
        
            # Extract face region of interest (ROI)
            grayROI = gray[y:y+h, x:x+w]

            # Predict label of face ROI
            label,cvalue = recognizer.predict(grayROI)

        print(int(cvalue))
        
        if cvalue != 0:
            arr_conf.append(cvalue)
            arr_var+=1 #represents no. of elements in list
        count+=1 #represnts number of cvalue value generated 
    
        if arr_var==sam_conf or count == 50 :
            break #breaking the list when list is full
    print()
    arr_conf.sort()
    
    mean_conf = int((sum(arr_conf[0:11])))/10
    print("Value Obtained : ",mean_conf)

    if mean_conf <= 44 and mean_conf > 0:
        print("Face Recognised")

        # Set the GPIO mode and pin
        #GPIO.setmode(GPIO.BOARD)
        #GPIO.setup(12, GPIO.OUT)

        # Set the PWM frequency and start the PWM
       # pnn = GPIO.PWM(12, 50)  # GPIO 12, 50Hz
       # pnn.start(0)

        # Rotate the servo by 45 degrees
        duty_rotcycle = 7.5  # Center position
       #pnn.ChangeDutyCycle(duty_rotcycle + 0.15)  # Rotate 45 degrees
        time.sleep(1)  # Wait for 1 second

        # Stop the PWM and cleanup
       # pnn.stop()
        #GPIO.cleanup()

    elif mean_conf>44:
        print("stranger")
    else:
        print("No Face Detected")
    cam_frame.release()
    cv2.destroyAllWindows()

#################

GPIO.setmode(GPIO.BCM)

# Set GPIO pin number for IR sensor input
ir_pin = 14

# Initialize GPIO pin for IR sensor input
GPIO.setup(ir_pin, GPIO.IN)

# Define function to print IR sensor status
def print_ir_status(channel):
    if GPIO.input(channel):
        print("Detected")
        auto_fr()
# Add event detection for rising and falling edges of IR sensor input
GPIO.add_event_detect(ir_pin, GPIO.BOTH, callback=print_ir_status)

# Wait for user to terminate program
input("Press any key to exit...\n")

# Clean up GPIO pins
GPIO.cleanup()
