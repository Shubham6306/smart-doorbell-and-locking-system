import tkinter as tk
from datetime import datetime

root = tk.Tk()

# set the window size and position
window_width = 250
window_height = 150
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x_coordinate = int((screen_width / 2) - (window_width / 2))
y_coordinate = int((screen_height / 2) - (window_height / 2))
root.geometry("{}x{}+{}+{}".format(window_width, window_height, x_coordinate, y_coordinate))

# set the window title
root.title("Face Added")

# create the label and set its properties
label1 = tk.Label(root, text="Name : Sankalp")
label1.pack(pady=15)
label = tk.Label(root, text="Face Added: {}".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
label.pack(pady=5)


# create the button and set its properties
button = tk.Button(root, text="Okay", command=root.destroy)
button.pack(side="bottom" ,pady="20")

root.mainloop()
