import cv2
import datetime
import os

# Open the camera
cap = cv2.VideoCapture(0)

# Check if camera is opened
if not cap.isOpened():
    print("Could not open camera")
    exit()

# Capture a frame
ret, frame = cap.read()

# Get the current date and time
now = datetime.datetime.now()
date = now.strftime("%d-%m-%Y")
time = now.strftime("%I:%M %p")

# Create a new folder with the name in the format of date
folder_path = os.path.expanduser("~/Desktop/Project/Log/" + date)
if not os.path.exists(folder_path):
    os.makedirs(folder_path)

# Save the frame as an image in the new folder with the name in the format of time
filename = os.path.join(folder_path, time + '.jpg')
cv2.imwrite(filename, frame)

# Release the camera
cap.release()

print("Image saved as", filename)
